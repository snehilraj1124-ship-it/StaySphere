from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, os
from datetime import datetime

app = Flask(__name__)
app.secret_key = "staysphere-demo"
DB = os.path.join(os.path.dirname(__file__), "staysphere.db")

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS rooms(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        number TEXT UNIQUE NOT NULL,
        room_type TEXT NOT NULL,
        price REAL NOT NULL,
        status TEXT DEFAULT 'Available'
    );
    CREATE TABLE IF NOT EXISTS guests(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        id_type TEXT,
        id_number TEXT
    );
    CREATE TABLE IF NOT EXISTS reservations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guest_id INTEGER NOT NULL,
        room_id INTEGER NOT NULL,
        check_in TEXT NOT NULL,
        check_out TEXT NOT NULL,
        guests INTEGER DEFAULT 1,
        status TEXT DEFAULT 'Confirmed',
        total REAL DEFAULT 0,
        FOREIGN KEY(guest_id) REFERENCES guests(id),
        FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
    CREATE TABLE IF NOT EXISTS invoices(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reservation_id INTEGER NOT NULL,
        description TEXT NOT NULL,
        amount REAL NOT NULL,
        status TEXT DEFAULT 'Pending',
        invoice_date TEXT NOT NULL,
        FOREIGN KEY(reservation_id) REFERENCES reservations(id)
    );
    """)
    if c.execute("SELECT COUNT(*) n FROM rooms").fetchone()["n"] == 0:
        c.executemany(
            "INSERT INTO rooms(number,room_type,price,status) VALUES(?,?,?,?)",
            [
                ("101","Standard",3200,"Available"),
                ("102","Standard",3200,"Occupied"),
                ("201","Deluxe",4800,"Available"),
                ("202","Deluxe",4800,"Available"),
                ("301","Executive",6500,"Available"),
                ("302","Executive",6500,"Maintenance"),
                ("401","Suite",9500,"Available"),
                ("402","Suite",9500,"Available"),
            ]
        )
        c.executemany(
            "INSERT INTO guests(name,phone,email,id_type,id_number) VALUES(?,?,?,?,?)",
            [
                ("Arjun Mehta","+91 98765 11001","arjun@example.com","Passport","P1234567"),
                ("Riya Sharma","+91 98765 11002","riya@example.com","Aadhaar","XXXX-XXXX-1122"),
                ("Kabir Rao","+91 98765 11003","kabir@example.com","Driving License","DL-09-4455"),
            ]
        )
        today = datetime.now().strftime("%Y-%m-%d")
        c.execute("""INSERT INTO reservations
            (guest_id,room_id,check_in,check_out,guests,status,total)
            VALUES(?,?,?,?,?,?,?)""",(1,2,today,today,"2","Checked-In",3200))
        c.execute("""INSERT INTO reservations
            (guest_id,room_id,check_in,check_out,guests,status,total)
            VALUES(?,?,?, ?,?,?,?)""",(2,3,today,"2099-12-31",1,"Confirmed",4800))
        c.execute("""INSERT INTO invoices
            (reservation_id,description,amount,status,invoice_date)
            VALUES(?,?,?,?,?)""",(1,"Room stay",3200,"Paid",today))
    c.commit()
    c.close()

@app.route("/")
def dashboard():
    c=db()
    stats={
        "rooms":c.execute("SELECT COUNT(*) n FROM rooms").fetchone()["n"],
        "available":c.execute("SELECT COUNT(*) n FROM rooms WHERE status='Available'").fetchone()["n"],
        "occupied":c.execute("SELECT COUNT(*) n FROM rooms WHERE status='Occupied'").fetchone()["n"],
        "revenue":c.execute("SELECT COALESCE(SUM(amount),0) x FROM invoices WHERE status='Paid'").fetchone()["x"],
        "bookings":c.execute("SELECT COUNT(*) n FROM reservations WHERE status IN ('Confirmed','Checked-In')").fetchone()["n"]
    }
    types=c.execute("""SELECT room_type,COUNT(*) rooms,COALESCE(SUM(price),0) nightly_rate
                       FROM rooms GROUP BY room_type ORDER BY price""").fetchall()
    recent=c.execute("""SELECT r.*,g.name guest,rm.number room,rm.room_type
                        FROM reservations r JOIN guests g ON g.id=r.guest_id
                        JOIN rooms rm ON rm.id=r.room_id
                        ORDER BY r.id DESC LIMIT 8""").fetchall()
    c.close()
    return render_template("dashboard.html",stats=stats,types=types,recent=recent)

@app.route("/rooms",methods=["GET","POST"])
def rooms():
    c=db()
    if request.method=="POST":
        try:
            c.execute("INSERT INTO rooms(number,room_type,price,status) VALUES(?,?,?,?)",
                      (request.form["number"],request.form["room_type"],request.form["price"],request.form["status"]))
            c.commit(); flash("Room added successfully.")
        except sqlite3.IntegrityError:
            flash("Room number already exists.")
        c.close(); return redirect(url_for("rooms"))
    rows=c.execute("SELECT * FROM rooms ORDER BY CAST(number AS INTEGER)").fetchall()
    c.close()
    return render_template("rooms.html",rows=rows)

@app.route("/guests",methods=["GET","POST"])
def guests():
    c=db()
    if request.method=="POST":
        c.execute("""INSERT INTO guests(name,phone,email,id_type,id_number)
                     VALUES(?,?,?,?,?)""",
                  (request.form["name"],request.form["phone"],request.form["email"],
                   request.form["id_type"],request.form["id_number"]))
        c.commit(); c.close(); flash("Guest registered.")
        return redirect(url_for("guests"))
    rows=c.execute("SELECT * FROM guests ORDER BY id DESC").fetchall()
    c.close()
    return render_template("guests.html",rows=rows)

@app.route("/reservations",methods=["GET","POST"])
def reservations():
    c=db()
    if request.method=="POST":
        room_id=int(request.form["room_id"])
        guest_id=int(request.form["guest_id"])
        room=c.execute("SELECT * FROM rooms WHERE id=?",(room_id,)).fetchone()
        if not room or room["status"] != "Available":
            flash("Selected room is not available.")
        else:
            ci=datetime.strptime(request.form["check_in"],"%Y-%m-%d")
            co=datetime.strptime(request.form["check_out"],"%Y-%m-%d")
            nights=(co-ci).days
            if nights <= 0:
                flash("Check-out must be after check-in.")
            else:
                total=nights*room["price"]
                c.execute("""INSERT INTO reservations
                    (guest_id,room_id,check_in,check_out,guests,status,total)
                    VALUES(?,?,?,?,?,?,?)""",
                    (guest_id,room_id,request.form["check_in"],request.form["check_out"],
                     request.form["guests"],"Confirmed",total))
                c.execute("UPDATE rooms SET status='Occupied' WHERE id=?",(room_id,))
                c.commit(); flash("Reservation confirmed.")
        c.close(); return redirect(url_for("reservations"))
    rows=c.execute("""SELECT r.*,g.name guest,rm.number room,rm.room_type
                      FROM reservations r JOIN guests g ON g.id=r.guest_id
                      JOIN rooms rm ON rm.id=r.room_id ORDER BY r.id DESC""").fetchall()
    guests_list=c.execute("SELECT * FROM guests ORDER BY name").fetchall()
    rooms_list=c.execute("SELECT * FROM rooms WHERE status='Available' ORDER BY number").fetchall()
    c.close()
    return render_template("reservations.html",rows=rows,guests=guests_list,rooms=rooms_list)

@app.route("/billing",methods=["GET","POST"])
def billing():
    c=db()
    if request.method=="POST":
        c.execute("""INSERT INTO invoices(reservation_id,description,amount,status,invoice_date)
                     VALUES(?,?,?,?,?)""",
                  (request.form["reservation_id"],request.form["description"],
                   request.form["amount"],request.form["status"],
                   datetime.now().strftime("%Y-%m-%d")))
        c.commit(); c.close(); flash("Invoice created.")
        return redirect(url_for("billing"))
    rows=c.execute("""SELECT i.*,g.name guest,rm.number room
                      FROM invoices i JOIN reservations r ON r.id=i.reservation_id
                      JOIN guests g ON g.id=r.guest_id JOIN rooms rm ON rm.id=r.room_id
                      ORDER BY i.id DESC""").fetchall()
    res=c.execute("""SELECT r.id,g.name guest,rm.number room,r.total
                     FROM reservations r JOIN guests g ON g.id=r.guest_id
                     JOIN rooms rm ON rm.id=r.room_id ORDER BY r.id DESC""").fetchall()
    c.close()
    return render_template("billing.html",rows=rows,reservations=res)

@app.route("/availability")
def availability():
    c=db()
    rows=c.execute("SELECT * FROM rooms ORDER BY room_type,number").fetchall()
    c.close()
    return render_template("availability.html",rows=rows)

if __name__=="__main__":
    init_db()
    app.run(debug=True)
