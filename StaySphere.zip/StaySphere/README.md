# 🏨 StaySphere — Hotel Management Platform

StaySphere is a full-stack hotel management platform built with Python and Flask. It provides centralized control over room inventory, guest registration, reservations, availability, check-in status, billing, and occupancy operations.

## 🚀 Features

- 🛏️ Room inventory management
- 👤 Guest registration
- 📅 Reservation engine
- 🔄 Dynamic room availability
- 🏨 Occupancy status tracking
- 💳 Billing and invoice management
- 📊 Occupancy and revenue dashboard
- 🔎 Room availability view
- 🗄️ SQLite relational database
- 🌱 Seeded demo data

## 🛠️ Tech Stack

- Python
- Flask
- SQLite
- SQL
- Jinja2
- HTML5
- CSS3

## 📁 Project Structure

```text
StaySphere/
├── app.py
├── requirements.txt
├── README.md
└── templates/
    ├── base.html
    ├── dashboard.html
    ├── rooms.html
    ├── guests.html
    ├── reservations.html
    ├── billing.html
    └── availability.html
```

## ⚙️ Installation

### Windows

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

### macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

The `staysphere.db` database is created automatically.

## 🏗️ Core Modules

### Room Management
Manage room number, room type, nightly price, and operational status.

### Guest Management
Maintain guest contact and identification details.

### Reservation Engine
Create reservations, calculate stay cost from the number of nights, and update room occupancy.

### Availability
View all rooms with their current status, including Available, Occupied, and Maintenance.

### Billing
Generate invoices against reservations and track Paid/Pending payment status.

### Dashboard
Monitor total rooms, available rooms, occupied rooms, active bookings, and paid revenue.

## 🔄 Reservation Workflow

```text
Guest Registration
       ↓
Room Availability Check
       ↓
Reservation Creation
       ↓
Night Calculation
       ↓
Total Price Calculation
       ↓
Room Status Update
       ↓
Invoice / Payment
```

## 🧮 Pricing Logic

For a reservation:

```text
Total = Number of Nights × Room Nightly Rate
```

The system validates that:

- The room exists
- The room is available
- Check-out is after check-in
- A valid guest is selected

## 🗄️ Database Tables

```text
rooms
guests
reservations
invoices
```

Relationships:

```text
Guests
   │
   └── Reservations ─── Rooms
             │
             └── Invoices
```

## 🔮 Future Enhancements

- Online payment gateway
- Guest authentication
- Admin and receptionist roles
- Check-in/check-out workflow
- Room cleaning/housekeeping module
- Booking cancellation and refund workflow
- Seasonal/dynamic pricing
- Discount and coupon engine
- GST/tax invoices
- PDF invoice generation
- Email booking confirmation
- REST API
- PostgreSQL
- Redis caching
- Docker deployment
- Advanced occupancy analytics
- Revenue forecasting

## ⚠️ Disclaimer

StaySphere is an educational and portfolio project. It is not intended as a production hotel booking system without additional authentication, authorization, payment security, concurrency controls, audit logging, testing, and deployment hardening.

## 🎯 Project Type

**Full-Stack Hotel Management Platform**

Built to demonstrate database-driven business workflows, reservation logic, inventory/status management, billing, and operational analytics.

---

### 🏨 StaySphere

**Manage rooms. Streamline reservations. Understand occupancy.**
